package com.example.selen.stevebot;

public class DiscordBot extends MediaSkeleton {
}
