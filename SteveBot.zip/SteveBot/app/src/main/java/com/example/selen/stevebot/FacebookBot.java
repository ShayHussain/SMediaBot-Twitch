package com.example.selen.stevebot;

public class FacebookBot extends MediaSkeleton {
}
