package com.example.selen.stevebot;

public class InstagramBot extends MediaSkeleton {
}
