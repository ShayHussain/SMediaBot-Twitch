package com.example.selen.stevebot;
import java.util.*;

public abstract class MediaSkeleton {

    protected String oAuth;
    protected String message;



    public MediaSkeleton(String oAuth, String message) {
        this.oAuth = oAuth;
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getoAuth() {
        return oAuth;
    }

    public void setoAuth(String oAuth) {
        this.oAuth = oAuth;
    }

    public abstract void connect();

    public abstract void post();
}
